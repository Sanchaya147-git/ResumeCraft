import React, { useState } from "react";
import { Link } from "react-router-dom";

function Builder() {
  const [formData, setFormData] = useState({
    name: "",
    role: "",
    email: "",
    phone: "",
    location: "",
    summary: "",
    education: "",
    skills: "",
    projects: "",
    experience: ""
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <main className="builder-page">

      <div className="builder-container">

        {/* HEADER */}

        <div className="builder-header">
          <div className="builder-label">
            ✦ RESUME BUILDER
          </div>

          <h1>
            Build Your <span>Resume</span>
          </h1>

          <p>
            Enter your information and watch your professional
            resume come together instantly.
          </p>

          <Link to="/templates" className="change-template">
            ← Change Template
          </Link>
        </div>

        {/* MAIN BUILDER */}

        <div className="builder-content">

          {/* FORM */}

          <div className="builder-form">

            <h2>Personal Information</h2>

            <div className="form-grid">

              <div className="form-group">
                <label>Full Name</label>
                <input
                  type="text"
                  name="name"
                  placeholder="Enter your full name"
                  value={formData.name}
                  onChange={handleChange}
                />
              </div>

              <div className="form-group">
                <label>Professional Title</label>
                <input
                  type="text"
                  name="role"
                  placeholder="e.g. Software Developer"
                  value={formData.role}
                  onChange={handleChange}
                />
              </div>

              <div className="form-group">
                <label>Email</label>
                <input
                  type="email"
                  name="email"
                  placeholder="you@example.com"
                  value={formData.email}
                  onChange={handleChange}
                />
              </div>

              <div className="form-group">
                <label>Phone</label>
                <input
                  type="text"
                  name="phone"
                  placeholder="+91 XXXXX XXXXX"
                  value={formData.phone}
                  onChange={handleChange}
                />
              </div>

              <div className="form-group full-width">
                <label>Location</label>
                <input
                  type="text"
                  name="location"
                  placeholder="City, Country"
                  value={formData.location}
                  onChange={handleChange}
                />
              </div>

            </div>

            {/* SUMMARY */}

            <div className="form-section">
              <h3>Professional Summary</h3>

              <div className="form-group">
                <label>About You</label>

                <textarea
                  name="summary"
                  placeholder="Write a short professional summary..."
                  value={formData.summary}
                  onChange={handleChange}
                />
              </div>
            </div>

            {/* EDUCATION */}

            <div className="form-section">
              <h3>Education</h3>

              <div className="form-group">
                <label>Education Details</label>

                <textarea
                  name="education"
                  placeholder="Degree, college, year, CGPA..."
                  value={formData.education}
                  onChange={handleChange}
                />
              </div>
            </div>

            {/* SKILLS */}

            <div className="form-section">
              <h3>Skills</h3>

              <div className="form-group">
                <label>Technical Skills</label>

                <textarea
                  name="skills"
                  placeholder="Python, Java, SQL, React..."
                  value={formData.skills}
                  onChange={handleChange}
                />
              </div>
            </div>

            {/* PROJECTS */}

            <div className="form-section">
              <h3>Projects</h3>

              <div className="form-group">
                <label>Project Details</label>

                <textarea
                  name="projects"
                  placeholder="Project name, technologies and description..."
                  value={formData.projects}
                  onChange={handleChange}
                />
              </div>
            </div>

            {/* EXPERIENCE */}

            <div className="form-section">
              <h3>Experience</h3>

              <div className="form-group">
                <label>Internships / Experience</label>

                <textarea
                  name="experience"
                  placeholder="Company, role, duration and responsibilities..."
                  value={formData.experience}
                  onChange={handleChange}
                />
              </div>
            </div>

          </div>

          {/* LIVE PREVIEW */}

          <div className="preview-card">

            <div className="preview-label">
              LIVE PREVIEW
            </div>

            <h2>Your Resume</h2>

            <p className="preview-title">
              Updates automatically as you type
            </p>

            <div className="resume-preview">

              <h1>
                {formData.name || "Your Name"}
              </h1>

              <p>
                {formData.role || "Professional Title"}
              </p>

              {(formData.email ||
                formData.phone ||
                formData.location) && (
                <p>
                  {formData.email}
                  {formData.email && formData.phone ? " • " : ""}
                  {formData.phone}
                  {(formData.email || formData.phone) &&
                    formData.location
                    ? " • "
                    : ""}
                  {formData.location}
                </p>
              )}

              <h3>PROFILE</h3>

              <p>
                {formData.summary ||
                  "Your professional summary will appear here."}
              </p>

              <h3>EDUCATION</h3>

              <p>
                {formData.education ||
                  "Your education details will appear here."}
              </p>

              <h3>SKILLS</h3>

              <p>
                {formData.skills ||
                  "Your skills will appear here."}
              </p>

              <h3>PROJECTS</h3>

              <p>
                {formData.projects ||
                  "Your project details will appear here."}
              </p>

              <h3>EXPERIENCE</h3>

              <p>
                {formData.experience ||
                  "Your experience will appear here."}
              </p>

            </div>

          </div>

        </div>
      </div>
    </main>
  );
}

export default Builder;