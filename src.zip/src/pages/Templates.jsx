import React from "react";
import { useNavigate } from "react-router-dom";

const templates = [
  {
    id: "professional",
    name: "Professional",
    description:
      "A clean and elegant design perfect for corporate and professional roles.",
  },
  {
    id: "modern",
    name: "Modern",
    description:
      "A stylish modern layout designed to make your resume stand out.",
  },
  {
    id: "minimal",
    name: "Minimal",
    description:
      "A simple and focused design that keeps your information clear.",
  },
];

function ProfessionalPreview() {
  return (
    <div className="resume-preview professional-preview">
      <div className="preview-header">
        <div className="preview-name"></div>
        <div className="preview-title"></div>
      </div>

      <div className="preview-section">
        <div className="preview-heading"></div>
        <div className="preview-line long"></div>
        <div className="preview-line medium"></div>
        <div className="preview-line short"></div>
      </div>

      <div className="preview-section">
        <div className="preview-heading"></div>
        <div className="preview-line long"></div>
        <div className="preview-line medium"></div>
        <div className="preview-line short"></div>
      </div>

      <div className="preview-section">
        <div className="preview-heading"></div>
        <div className="preview-line long"></div>
        <div className="preview-line medium"></div>
      </div>
    </div>
  );
}

function ModernPreview() {
  return (
    <div className="resume-preview modern-preview">
      <div className="modern-top">
        <div className="modern-name"></div>
        <div className="modern-contact"></div>
      </div>

      <div className="modern-layout">
        <div className="modern-sidebar">
          <div className="preview-heading"></div>
          <div className="preview-line"></div>
          <div className="preview-line"></div>
          <div className="preview-line short"></div>

          <div className="preview-heading second"></div>
          <div className="preview-line"></div>
          <div className="preview-line short"></div>
        </div>

        <div className="modern-content">
          <div className="preview-heading"></div>
          <div className="preview-line long"></div>
          <div className="preview-line long"></div>
          <div className="preview-line medium"></div>

          <div className="preview-heading second"></div>
          <div className="preview-line long"></div>
          <div className="preview-line medium"></div>
          <div className="preview-line short"></div>
        </div>
      </div>
    </div>
  );
}

function MinimalPreview() {
  return (
    <div className="resume-preview minimal-preview">
      <div className="minimal-name"></div>
      <div className="minimal-contact"></div>

      <div className="minimal-divider"></div>

      <div className="minimal-section">
        <div className="minimal-heading"></div>
        <div className="preview-line long"></div>
        <div className="preview-line long"></div>
        <div className="preview-line medium"></div>
      </div>

      <div className="minimal-section">
        <div className="minimal-heading"></div>
        <div className="preview-line long"></div>
        <div className="preview-line medium"></div>
      </div>

      <div className="minimal-section">
        <div className="minimal-heading"></div>
        <div className="preview-line long"></div>
        <div className="preview-line short"></div>
      </div>
    </div>
  );
}

function TemplatePreview({ type }) {
  if (type === "professional") {
    return <ProfessionalPreview />;
  }

  if (type === "modern") {
    return <ModernPreview />;
  }

  return <MinimalPreview />;
}

export default function Templates() {
  const navigate = useNavigate();

  const handleTemplate = (template) => {
    localStorage.setItem("selectedTemplate", template.id);
    navigate("/builder");
  };

  return (
    <div className="templates-page">
      <section className="templates-hero">
        <div className="templates-label">
          <span>✦</span>
          RESUME TEMPLATES
        </div>

        <h1>
          Choose Your <span>Template</span>
        </h1>

        <p>
          Start with a beautiful design and customize it with your own
          information.
        </p>
      </section>

      <section className="templates-grid">
        {templates.map((template) => (
          <article
            className={`template-card ${template.id}-card`}
            key={template.id}
          >
            <div className="template-preview-container">
              <TemplatePreview type={template.id} />
            </div>

            <div className="template-content">
              <h2>{template.name}</h2>

              <p>{template.description}</p>

              <button
                className="template-button"
                onClick={() => handleTemplate(template)}
              >
                Use Template <span>→</span>
              </button>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}